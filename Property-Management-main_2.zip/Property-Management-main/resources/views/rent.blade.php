@extends('layout.app')
@section('title','Rent')



