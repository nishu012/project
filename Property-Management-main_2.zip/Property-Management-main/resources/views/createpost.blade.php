@extends('layout.app')

@section('title','CreatePost')